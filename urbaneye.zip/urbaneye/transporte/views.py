from django.shortcuts import render
from .models import Transporte, Incidente

def inicio(request):
    transportes = Transporte.objects.all()
    incidentes = Incidente.objects.all()
    return render(request, 'transporte/inicio.html', {'transportes': transportes, 'incidentes': incidentes})

