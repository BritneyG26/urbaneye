from django.db import models

class Transporte(models.Model):
    nombre = models.CharField(max_length=100)
    tipo = models.CharField(max_length=50, choices=[
        ("bus", "Bus"),
        ("metro", "Metro"),
        ("tren", "Tren")
    ])
    ubicacion_actual = models.CharField(max_length=255)
    capacidad = models.IntegerField()
    actualizado_en = models.DateTimeField(auto_now=True)

class Incidente(models.Model):
    descripcion = models.TextField()
    ubicacion = models.CharField(max_length=255)
    tipo = models.CharField(max_length=100, choices=[
        ("accidente", "Accidente"),
        ("demora", "Demora")
    ])
    fecha = models.DateTimeField(auto_now_add=True)

